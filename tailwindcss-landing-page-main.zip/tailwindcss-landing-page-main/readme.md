# Baca Saya

ini adalah project sederhana membuat landing page dengan menggunakan tailwindcss. Petunjuk bisa dilihat di link https://www.youtube.com/watch?v=eFU1M658RnU
